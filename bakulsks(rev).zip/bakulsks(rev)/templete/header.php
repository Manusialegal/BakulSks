<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?= $title ?></title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="<?= $main_url ?>asset/sb-ecommers/css/styles.css" rel="stylesheet" />
        <link rel="shortcut icon" href="<?= $main_url ?>asset/image/Logo ITH.png" type="image/x-icon">
    </head>

    <!-- Header-->
    <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Selamat Datang di E-canteen ITH</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Kami menyediakan berbagai macam makanan dan minuman yang lezat dan sehat untuk Anda.</p>
                </div>
            </div>
        </header>