<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasi Goreng</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
</head>
<body>
    <?php require "navbar.php"; ?>\

    <section class="py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img style ="width: 500px;
                    height: 700px;" src="../img/Nasi Goreng.jpg" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="small mb-1">Resep</div>
                        <h1 class="display-5 fw-bolder">Nasi Goreng</h1>
                        <h5 class="lead">Berikut adalah resep sederhana untuk membuat nasi goreng:
                            <br>Bahan-bahan:</br>
                            <br>- 2 piring nasi putih (lebih baik jika nasi sudah dingin atau sisa semalam)
                            <br>- 2 butir telur 100 gram ayam fillet, potong kecil-kecil
                            <br>- 2 siung bawang putih, cincang halus
                            <br>- 1 buah bawang merah, cincang halus
                            <br>- 1 buah wortel, potong dadu kecil
                            <br>- 1 batang daun bawang, iris tipis
                            <br>- 2 sendok makan kecap manis
                            <br>- 1 sendok makan kecap asin
                            <br>- 1 sendok teh saus tiram
                            <br>- Garam dan merica secukupnya
                            <br>- Minyak goreng secukupnya
                            <br>Cara membuat:
                            <br>Panaskan sedikit minyak goreng dalam wajan.
                            Tumis bawang putih dan bawang merah hingga harum.
                            Masukkan ayam fillet, masak hingga ayam berubah warna dan matang.</br>
                            Geser ayam ke pinggir wajan, masukkan telur, aduk dan orak-arik hingga matang.</br>
                            Masukkan wortel, aduk rata dan masak hingga wortel setengah matang.</br>
                            Masukkan nasi putih, aduk hingga semua bahan tercampur rata.
                            Tambahkan kecap manis, kecap asin, saus tiram, garam, dan merica. Aduk rata.
                            Masak hingga nasi panas dan bumbu meresap, kemudian tambahkan daun bawang iris.
                            Angkat dan sajikan nasi goreng dengan pelengkap seperti acar, kerupuk, atau irisan mentimun dan tomat.
                            Selamat menikmati nasi goreng buatan Anda!</h5>
                        <div class="d-flex">
                            <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1" style="max-width: 3rem" />
                            <button class="btn btn-outline-dark flex-shrink-0" type="button">
                                <i class="bi-cart-fill me-1"></i>
                                Pesan sekarang
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Related items section-->
        <section class="py-5 bg-light">
            <div class="container px-4 px-lg-5 mt-5">
                <h2 class="fw-bolder mb-4">Produk yang lain</h2>
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/Mie ayam.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Mie ayam</h5>
                                    <!-- Product price-->
                                    Rp40.000 - Rp.30.000
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Mieayam.php">View options</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/ayam geprek.jpeg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Ayam Geprek</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">Rp.20.000</span>
                                    Rp.71.000
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="ayamgeprek.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Alpukat</h5>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">$50.00</span>
                                    $25.00
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusalpukat.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Buah Naga</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    $40.00
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusbuahnaga.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
        <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>