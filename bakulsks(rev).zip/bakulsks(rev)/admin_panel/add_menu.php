<?php
session_start();
require "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['alarm_hour']) && isset($_POST['alarm_minute'])) {
        $hour = intval($_POST['alarm_hour']);
        $minute = intval($_POST['alarm_minute']);

        // Simpan waktu alarm dalam session
        $_SESSION['alarms'][] = ['hour' => $hour, 'minute' => $minute];
        header("Location: menu.php");
        exit();
    }
}
?>