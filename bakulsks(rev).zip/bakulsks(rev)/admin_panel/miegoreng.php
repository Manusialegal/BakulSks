<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasi Goreng</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
</head>
<body>
    <?php require "navbar.php"; ?>\

    <section class="py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img style ="width: 500px;
                    height: 700px;" src="../img/miegoreng.jpg" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="small mb-1">Resep</div>
                        <h1 class="display-5 fw-bolder">Mie Goreng</h1>
                        <p class="lead">Berikut adalah resep sederhana untuk membuat ayam goreng bumbu kuning:

                                Bahan-bahan:
                                <br>1 ekor ayam, potong menjadi beberapa bagian
                                <br>2 lembar daun salam
                                <br>2 batang serai, memarkan
                                <br>4 lembar daun jeruk
                                <br> 1 ruas lengkuas, memarkan
                                <br>500 ml air kelapa (opsional, bisa diganti dengan air biasa)
                                <br>Minyak untuk menggoreng
                                <br> Bumbu Halus:
                                <br>6 siung bawang putih
                                <br>8 butir bawang merah
                                <br>4 butir kemiri, sangrai
                                <br>1 ruas kunyit, bakar sebentar
                                <br>1 ruas jahe
                                <br>1 sendok teh ketumbar
                                <br>1 sendok teh garam
                                <br>1/2 sendok teh merica
                                <br>Cara Membuat:
                                Cuci bersih potongan ayam, lalu tiriskan.
                                Haluskan semua bumbu halus dengan menggunakan blender atau ulekan.
                                Panaskan sedikit minyak dalam wajan, tumis bumbu halus hingga harum.
                                Masukkan daun salam, serai, daun jeruk, dan lengkuas. Aduk rata dan tumis sebentar.
                                Tambahkan potongan ayam ke dalam wajan. Aduk hingga ayam berubah warna.
                                Tuang air kelapa atau air biasa ke dalam wajan. Masak dengan api sedang hingga ayam matang dan bumbu meresap. Sesekali aduk agar bumbu merata.
                                Setelah ayam matang dan kuah menyusut, angkat ayam dan tiriskan.
                                Panaskan minyak dalam wajan yang berbeda, goreng ayam hingga kuning kecokelatan dan kulitnya garing.
                                Angkat dan tiriskan ayam goreng.</p>
                        <div class="d-flex">
                            <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1" style="max-width: 3rem" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Related items section-->
        <section class="py-5 bg-light">
            <div class="container px-4 px-lg-5 mt-5">
                <h2 class="fw-bolder mb-4">Produk yang lain</h2>
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/Mie ayam.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Mie ayam</h5>
                                    <!-- Product price-->
                                    Rp40.000 - Rp.30.000
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Mieayam.php">View options</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/ayam geprek.jpeg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Ayam Geprek</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">Rp.20.000</span>
                                    Rp.71.000
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="ayamgeprek.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Alpukat</h5>              
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusalpukat.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Buah Naga</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    $40.00
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusbuahnaga.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
        <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>