<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasi Goreng</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
</head>
<body>
    <?php require "navbar.php"; ?>\

    <section class="py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="../img/nasikanse.jpeg" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="small mb-1">Resep</div>
                        <h1 class="display-5 fw-bolder">Nasi kanse</h1>
                        <p class="lead">
                            Berikut adalah resep untuk membuat Nasi Uduk, sebuah hidangan khas Indonesia yang lezat dan gurih:

                                    Bahan-bahan:

                                    500 gram beras, cuci bersih
                                    400 ml santan kental
                                    2 lembar daun salam
                                    2 batang serai, memarkan
                                    3 lembar daun jeruk
                                    2 cm jahe, memarkan
                                    1/2 sendok teh garam
                                    Cara membuat:

                                    Cuci bersih beras dan tiriskan.
                                    Campurkan santan, daun salam, serai, daun jeruk, jahe, dan garam dalam panci. Masak dengan api kecil sambil terus diaduk hingga santan mendidih.
                                    Masukkan beras ke dalam santan yang telah mendidih. Aduk rata hingga santan meresap ke dalam beras dan beras setengah matang.
                                    Pindahkan beras yang sudah setengah matang ke dalam kukusan. Kukus selama kurang lebih 30 menit atau hingga nasi matang dan pulen.
                                    Angkat dan aduk-aduk nasi agar bumbu tercampur merata. Biarkan sebentar agar nasi lebih pulen.
                                    Penyajian:
                                    Nasi uduk biasanya disajikan dengan berbagai lauk seperti ayam goreng, telur dadar, tempe orek, sambal, dan irisan mentimun. Bisa juga ditambahkan bawang goreng di atasnya untuk menambah cita rasa.

                                    Selamat mencoba!</p>
                        <div class="d-flex">
                            <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1" style="max-width: 3rem" />
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Related items section-->
        <section class="py-5 bg-light">
            <div class="container px-4 px-lg-5 mt-5">
                <h2 class="fw-bolder mb-4">Produk yang lain</h2>
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/Mie ayam.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Mie ayam</h5>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Mieayam.php">Liat sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem"></div>
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/ayam geprek.jpeg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Ayam Geprek</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="ayamgeprek.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/nasikanse.jpeg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Nasi Kanse</h5>
                                    <!-- Product price-->
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="nasikanse.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/bakwan.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Bakwan</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div> 
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Bakwan.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
        <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>