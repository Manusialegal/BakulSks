<?php
require "session.php";
require "../config.php";

$role = isset($_SESSION['role']) ? $_SESSION['role'] : 'guest';

$queryMakanan = mysqli_query($con, "SELECT * FROM tbl_makanan");
$jumlahMakanan = mysqli_num_rows($queryMakanan);

$queryMinuman = mysqli_query($con, "SELECT * FROM tbl_minuman");
$jumlahMinuman = mysqli_num_rows($queryMinuman);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .navbar-custom {
            background-color: #343a40;
        }
        .navbar-custom .nav-link {
            color: #ffffff;
        }
        .navbar-custom .nav-link:hover {
            color: #f8f9fa;
        }
        .navbar-brand {
            font-size: 1.75em;
            font-weight: bold;
            color: #ffffff;
        }
        .navbar-brand:hover {
            color: #f8f9fa;
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.1);
        }
        .navbar-toggler-icon {
            color: #ffffff;
        }
        .summary-box {
            background-color: #343a40;
            border-radius: 10px;
            padding: 20px;
            color: #ffffff;
            transition: transform 0.3s ease-in-out;
        }
        .summary-box:hover {
            transform: scale(1.05);
        }
        .summary-box h3 {
            font-size: 2rem;
            margin-bottom: 15px;
        }
        .summary-box p {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }
        .summary-box a {
            color: #ffffff;
            text-decoration: none;
        }
        .summary-box a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php require "navbar.php"; ?>
    <header  class="bg-info py-5 text-white">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center">
                    <h1 class="display-4 fw-bolder">BakulSKS </h1>
                    <h2 class="lead fw-normal text-white mb-0">Silahkan Memilih Resep Yang Tersedia</h2>
                </div>
            </div>
        </header>
    <?php require "selecion.php"; ?>

        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; BakulSKS 2024</p></div>
        </footer>

    <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
    <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>
