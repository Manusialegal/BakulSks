<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar Example</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
    <style>
        .navbar-custom {
            background-color: #343a40; /* Warna latar belakang custom */
        }
        .navbar-custom .nav-link {
            color: #ffffff; /* Warna teks putih */
        }
        .navbar-custom .nav-link:hover {
            color: #f8f9fa; /* Warna teks saat hover */
        }
        .navbar-brand {
            font-size: 1.75em; /* Ukuran teks lebih besar */
            font-weight: bold;
            color: #ffffff; /* Warna teks putih */
        }
        .navbar-brand:hover {
            color: #f8f9fa; /* Warna teks saat hover */
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.1); /* Warna border tombol toggle */
        }
        .navbar-toggler-icon {
            color: #ffffff; /* Warna ikon toggle */
        }
        .navbar-logo {
            margin-right: 10px; /* Jarak antara logo dan teks */
            width: 50px; /* Lebar logo */
            height: auto; /* Tinggi logo menyesuaikan lebar */
        }
    </style>
</head>
<body>
    <?php
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : 'guest';
    ?>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
            <a class="navbar-brand text-white" href="../admin_panel">
                <img src="../img/logo_BakulSks.png" alt="Logo" class="navbar-logo"> BakulSKS
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item me-4">
                        <a class="nav-link" href="menu.php">Alaram Makan</a>
                    </li>
                    <?php if ($role == 'admin'): ?>
                    <li class="nav-item me-4">
                        <a class="nav-link" href="edit_menu.php">Edit Menu</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
    <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>
