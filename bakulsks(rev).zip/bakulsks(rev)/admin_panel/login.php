<?php
session_start();
include "config.php";

$message = "";

if (isset($_POST['loginbtn'])) {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    $query = mysqli_query($con, "SELECT * FROM tbl_user WHERE username='$username'");
    if ($query) {
        $countdata = mysqli_num_rows($query);
        if ($countdata > 0) {
            $data = mysqli_fetch_array($query);

            if (password_verify($password, $data['password'])) {
                $_SESSION['username'] = $username; 
                $_SESSION['login'] = true;
                $_SESSION['role'] = $data['role']; // Menyimpan role di sesi
                header('location:../admin_panel');
            } else {
                $message = '<div class="alert alert-danger" role="alert">Password Salah</div>';
            }
        } else {
            $message = '<div class="alert alert-warning" role="alert">Akun Tidak Tersedia</div>';
        }
    } else {
        echo "Error: " . mysqli_error($con);
    }
}

if (isset($_POST['logoutbtn'])) {
    session_unset(); 
    session_destroy(); 
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../asset/image/logo.png');
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .login-box {
            width: 350px;
            padding: 40px;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .login-box h2 {
            margin-bottom: 20px;
            color: #ff8c00;
            text-align: center;
        }
        .form-control {
            margin-bottom: 20px;
            border-radius: 25px;
            padding: 10px 20px;
        }
        .btn-custom {
            background-color: #ff8c00;
            border-color: #ff8c00;
            color: white;
            border-radius: 25px;
            transition: background-color 0.3s, transform 0.3s;
        }
        .btn-custom:hover {
            background-color: #e67e00;
            transform: translateY(-3px);
        }
        .notification {
            color: #ff8c00;
            margin-top: 10px;
            text-align: center;
        }
        .welcome-message {
            text-align: center;
            color: #ff8c00;
        }
        .logout-btn {
            background-color: #ff8c00;
            border-color: #ff8c00;
            color: white;
            border-radius: 25px;
            width: 100%;
            padding: 10px 0;
            margin-top: 20px;
            transition: background-color 0.3s, transform 0.3s;
        }
        .logout-btn:hover {
            background-color: #e67e00;
            transform: translateY(-3px);
        }
    </style>
</head>
<body>
    <div class="main">
        <?php if(isset($_SESSION['username'])): ?>
            <div class="login-box">
                <div class="welcome-message">
                    <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
                </div>
                <form action="" method="post">
                    <button class="logout-btn" type="submit" name="logoutbtn">Logout</button>
                </form>
            </div>
        <?php else: ?>
            <div class="login-box">
                <h2>Login</h2>
                <form action="" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" name="username" id="username" placeholder="Username">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                    </div>
                    <button class="btn btn-custom w-100" type="submit" name="loginbtn">Login</button>
                    <?php 
                    if(isset($message)){
                        echo '<div class="notification">'.$message.'</div>';
                    }
                    ?>
                </form>
            </div>
        <?php endif; ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
