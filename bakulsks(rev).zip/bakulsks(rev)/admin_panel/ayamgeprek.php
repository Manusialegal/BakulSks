<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasi Goreng</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
</head>
<body>
    <?php require "navbar.php"; ?>\

    <section class="py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="../img/ayam geprek.jpeg" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="small mb-1">Resep</div>
                        <h1 class="display-5 fw-bolder">Ayam Geprek</h1>
                        <p class="lead">
                                            Berikut adalah resep ayam geprek yang bisa Anda coba di rumah:

                                            Bahan-bahan:
                                            <br>500 gram ayam fillet (dada atau paha tanpa tulang), potong sesuai selera
                                            <br>2 siung bawang putih, haluskan
                                            <br>1 sendok teh garam
                                            <br>1/2 sendok teh merica bubuk
                                            <br>1 sendok makan air jeruk nipis
                                            Bahan Pelapis:
                                            <br>100 gram tepung terigu
                                            <br>50 gram tepung maizena
                                            <br>1/2 sendok teh baking powder
                                            <br>1/2 sendok teh garam
                                            <br>1/4 sendok teh merica bubuk
                                            <br>Air es secukupnya
                                            Bahan Sambal Geprek:
                                            <br>10 buah cabai rawit merah (sesuai selera pedas)
                                            <br>3 siung bawang putih
                                            <br>1/2 sendok teh garam
                                            <br>1/4 sendok teh gula pasir
                                            <br>Minyak panas secukupnya
                                                Cara Membuat:
                                                Marinasi Ayam:

                                            <br>Lumuri potongan ayam dengan bawang putih halus, garam, merica bubuk, dan air jeruk nipis. Diamkan selama 15-30 menit agar bumbu meresap.
                                                Mempersiapkan Pelapis:

                                            <br>Campurkan tepung terigu, tepung maizena, baking powder, garam, dan merica bubuk dalam wadah.
                                            <br>Bagi adonan tepung menjadi dua bagian. Satu bagian tambahkan air es sedikit demi sedikit hingga menjadi adonan cair kental, sementara satu bagian tetap dalam bentuk tepung kering.
                                                Menggoreng Ayam:

                                            <br>Panaskan minyak dalam wajan dengan api sedang.
                                            <br>Celupkan potongan ayam ke dalam adonan tepung kering, lalu ke dalam adonan cair, dan kembali ke dalam adonan tepung kering hingga terbalut rata.
                                            <br>Goreng ayam dalam minyak panas hingga kuning kecokelatan dan matang. Angkat dan tiriskan.
                                            <br>Membuat Sambal Geprek:

                                            <br>Ulek cabai rawit, bawang putih, garam, dan gula pasir hingga halus.
                                            <br>Siram dengan sedikit minyak panas bekas menggoreng ayam, aduk rata.
                                            <br>Menyajikan Ayam Geprek:

                                            <br>Geprek (tekan) ayam goreng dengan ulekan atau alat geprek hingga sedikit hancur.
                                            <br>Tuangkan sambal di atas ayam yang sudah digeprek, ratakan.
                                            <br>Sajikan ayam geprek dengan nasi hangat dan pelengkap seperti lalapan atau acar.
                                                Selamat mencoba dan menikmati ayam geprek buatan Anda!






                                                </p>
                        <div class="d-flex">
                            <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1" style="max-width: 3rem" />
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>       
        <section class="py-5 bg-light">
            <div class="container px-4 px-lg-5 mt-5">
                <h2 class="fw-bolder mb-4">Produk yang lain</h2>
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/Mie ayam.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Mie ayam</h5>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Mieayam.php">Liat sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem"></div>
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/ayam geprek.jpeg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Ayam Geprek</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="ayamgeprek.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Alpukat</h5>
                                    <!-- Product price-->
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusalpukat.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Buah Naga</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div> 
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusbuahnaga.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
        <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>