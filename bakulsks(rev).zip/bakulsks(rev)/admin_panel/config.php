<?php

$con = mysqli_connect("localhost","root","","db_kantin");

if (mysqli_connect_errno()){
    echo "gagal koneksi: " . mysqli_connect_errno();
    exit();
}
?>