<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasi Goreng</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
</head>
<body>
    <?php require "navbar.php"; ?>\

    <section class="py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="row gx-4 gx-lg-5 align-items-center">
                    <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="../img/pisanggoreng.jpeg" alt="..." /></div>
                    <div class="col-md-6">
                        <div class="small mb-1">Resep</div>
                        <h1 class="display-5 fw-bolder">Pisang Goereng</h1>
                        <div class="fs-5 mb-5">                           
                        </div>
                        <p class="lead">
                            Berikut adalah resep pisang goreng ala Dapur Umami:

                            Bahan-bahan:
                            6 buah pisang raja atau kepok, kupas dan potong sesuai selera
                            100 gram tepung terigu
                            50 gram tepung beras    
                            2 sendok makan gula pasir
                            1/4 sendok teh garam
                            200 ml air
                            Minyak goreng secukupnya
                            Bahan Pelapis:
                            2 sendok makan tepung roti (opsional, untuk hasil yang lebih renyah)
                            Cara membuat:
                            Membuat Adonan:

                            Campurkan tepung terigu, tepung beras, gula pasir, dan garam dalam sebuah mangkuk besar.
                            Tambahkan air sedikit demi sedikit sambil diaduk hingga adonan menjadi kental dan tidak ada gumpalan.
                            Mempersiapkan Pisang:

                            Celupkan potongan pisang ke dalam adonan tepung hingga seluruh permukaan pisang terbalut adonan.
                            Jika ingin lebih renyah, gulingkan pisang yang sudah berbalut adonan di atas tepung roti.
                            Menggoreng Pisang:

                            Panaskan minyak dalam wajan dengan api sedang.
                            Goreng pisang yang sudah berbalut adonan hingga kuning kecokelatan dan matang. Pastikan pisang terendam minyak dan goreng hingga renyah.
                            Angkat dan tiriskan pisang goreng dari minyak.
                            Penyajian:

                            Sajikan pisang goreng selagi hangat. Anda bisa menambahkan topping seperti susu kental manis atau taburan gula halus sesuai selera.
                            Selamat menikmati pisang goreng ala BakulSKS






                            </p>
                        <div class="d-flex">
                            <input class="form-control text-center me-3" id="inputQuantity" type="num" value="1" style="max-width: 3rem" />
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Related items section-->
        <section class="py-5 bg-light">
            <div class="container px-4 px-lg-5 mt-5">
                <h2 class="fw-bolder mb-4">Produk yang lain</h2>
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/Mie ayam.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Mie ayam</h5>
                                    <!-- Product price-->
                                    Rp40.000 - Rp.30.000
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Mieayam.php">View options</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="../img/ayam geprek.jpeg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Ayam Geprek</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>                                                                      
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="ayamgeprek.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Sale badge-->
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Sale</div>
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Alpukat</h5>
                                    <!-- Product price-->
                                    <span class="text-muted text-decoration-line-through">$50.00</span>
                                    $25.00
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusalpukat.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="https://dummyimage.com/450x300/dee2e6/6c757d.jpg" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder">Jus Buah Naga</h5>
                                    <!-- Product reviews-->
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                    <!-- Product price-->
                                    $40.00
                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="jusbuahnaga.php">Lihat Sekarang</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <script src="../bootstrap-5.3.3-dist/js/bootstrap.bundle.js"></script>
        <script src="../fontawesome-free-6.5.2-web/js/all.min.js"></script>
</body>
</html>