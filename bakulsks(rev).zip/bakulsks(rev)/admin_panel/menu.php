<?php
session_start();
require "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['alarm_hour']) && isset($_POST['alarm_minute'])) {
        $hour = intval($_POST['alarm_hour']);
        $minute = intval($_POST['alarm_minute']);

        // Simpan waktu alarm dalam session
        $_SESSION['alarms'][] = ['hour' => $hour, 'minute' => $minute];
        echo json_encode(['status' => 'success']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Alarm Makan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .notification {
            display: none;
            background-color: #f44336;
            color: white;
            text-align: center;
            padding: 15px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1;
        }
    </style>
</head>
<body>

<h1>Alarm Makan</h1>
<ul id="alarm-list">
    <?php
    if (isset($_SESSION['alarms'])) {
        foreach ($_SESSION['alarms'] as $alarm) {
            echo "<li>Alarm: " . sprintf("%02d", $alarm['hour']) . ":" . sprintf("%02d", $alarm['minute']) . "</li>";
        }
    }
    ?>
</ul>

<h2>Tambah Alarm Baru</h2>
<form id="alarm-form">
    <label for="alarm_hour">Jam:</label><br>
    <input type="number" id="alarm_hour" name="alarm_hour" min="0" max="23" required><br>
    <label for="alarm_minute">Menit:</label><br>
    <input type="number" id="alarm_minute" name="alarm_minute" min="0" max="59" required><br><br>
    <button type="button" onclick="addAlarm()">Tambah Alarm</button>
</form>

<div class="notification" id="notification">
    Ini saatnya makan!
</div>

<script>
    let alarms = <?php echo json_encode($_SESSION['alarms'] ?? []); ?>;

    function setAlarm(hour, minute) {
        const now = new Date();
        const alarmTime = new Date();

        alarmTime.setHours(hour);
        alarmTime.setMinutes(minute);
        alarmTime.setSeconds(0);

        if (now > alarmTime) {
            alarmTime.setDate(alarmTime.getDate() + 1);
        }

        const timeToAlarm = alarmTime - now;
        console.log('Alarm set for:', alarmTime); // Debugging

        setTimeout(showNotification, timeToAlarm);
    }

    function showNotification() {
        console.log('Notification shown'); // Debugging
        const notification = document.getElementById('notification');
        notification.style.display = 'block';
        setTimeout(() => {
            notification.style.display = 'none';
        }, 5000); // Notification will disappear after 5 seconds
    }

    // Set alarms
    alarms.forEach(alarm => {
        setAlarm(alarm.hour, alarm.minute);
    });

    function addAlarm() {
        const hour = document.getElementById('alarm_hour').value;
        const minute = document.getElementById('alarm_minute').value;

        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'menu.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.status === 'success') {
                    const alarmList = document.getElementById('alarm-list');
                    const newAlarm = document.createElement('li');
                    newAlarm.textContent = `Alarm: ${hour.padStart(2, '0')}:${minute.padStart(2, '0')}`;
                    alarmList.appendChild(newAlarm);

                    setAlarm(parseInt(hour), parseInt(minute));
                } else {
                    console.error('Failed to add alarm');
                }
            }
        };
        xhr.send(`alarm_hour=${hour}&alarm_minute=${minute}`);
    }
</script>

</body>
</html>