<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakul Sks</title>
    <link rel="stylesheet" href="../bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome-free-6.5.2-web/css/fontawesome.min.css">
</head>
<body>
    <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">                            
                            <img class="card-img-top" src="../img/Nasi Goreng.jpg" alt="..." />                          
                            <div class="card-body p-4">
                                <div class="text-center">                                   
                                    <h5 class="fw-bolder">Nasi Goreng</h5>                                                                      
                                </div>
                            </div>                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Nasigoreng.php">Lihat resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="../img/Mie ayam.jpg" alt="..." />                           
                            <div class="card-body p-4">
                                <div class="text-center">                                   
                                    <h5 class="fw-bolder">Mie ayam</h5>                                  
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>                                   
                                    <span class="text-muted text-decoration-line-through"></span>                                  
                                </div>
                            </div>                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Mieayam.php">Liat Resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem"></div>
                            
                            <img class="card-img-top" src="../img/ayam geprek.jpeg" alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder">Ayam Geprek</h5>    
                                </div>
                            </div>                        
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="ayamgeprek.php">Lihat Resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">                    
                            <img class="card-img-top" src="../img/bakwan.jpg" alt="..." />                         
                            <div class="card-body p-4">
                                <div class="text-center">                                  
                                    <h5 class="fw-bolder">Bakwan</h5>                      
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>
                                </div>
                            </div>                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="Bakwan.php">Lihat Resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">                            
                            <div class="badge bg-dark text-white position-absolute"></div>                   
                            <img class="card-img-top" src="../img/pisanggoreng.jpeg" alt="..." />                            
                            <div class="card-body p-4">
                                <div class="text-center">                                   
                                    <h5 class="fw-bolder">Pisang Goreng</h5>                                                                 
                                </div>
                            </div>

                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="pisanggoreng.php">Lihat Resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">                       
                            <img class="card-img-top" src="../img/miegoreng.jpg" alt="..." />                           
                            <div class="card-body p-4">
                                <div class="text-center">                                   
                                    <h5 class="fw-bolder">Mie Goreng</h5>                                              
                                </div>
                            </div>                            
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="miegoreng.php">lihat Resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            
                            <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">resep</div>
                            
                            <img class="card-img-top" src="../img/nasikanse.jpeg" alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder">Nasi Kanse </h5>
                                    
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>                           
                                </div>
                            </div>
                            
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="nasikanse.php">lihat resep</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            
                            <img class="card-img-top" src="../img/nasikuning.jpeg" alt="..." />
                            
                            <div class="card-body p-4">
                                <div class="text-center">
                                    
                                    <h5 class="fw-bolder">nasi kuning</h5>
                                    
                                    <div class="d-flex justify-content-center small text-warning mb-2">
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                        <div class="bi-star-fill"></div>
                                    </div>                                                           
                                </div>
                            </div>                           
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="nasikuning.php">Lihat Resep</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</body>
</html>